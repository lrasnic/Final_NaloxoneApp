/* !!! IMPORTANT: Rename "mymodule" below and add your module to Angular Modules above. */

angular.module('myApp', ['firebase'])
/*
.run(function(){
    // Initialize Firebase
  var config = {
    apiKey: "AIzaSyBmQm_DPp7H8DWboqm07lsWIb30EFSvotE",
    authDomain: "testing-nalox.firebaseapp.com",
    databaseURL: "https://testing-nalox.firebaseio.com",
    storageBucket: "testing-nalox.appspot.com",
    messagingSenderId: "395357414944"
  };
  firebase.initializeApp(config);
})



.service('Registration', ['$firebaseArray', function($firebaseArray){
    
    var ref = firebase.database().ref().child('registration');
    var items = $firebaseArray(ref);
    
    var registration = {
        'items': items,
        addItem: function(title){
            items.$add({
                'title': title,
            'finished': false
            });
            
        },
        setFinished: function(item, newV){
            item.finished = newV;
            items.$save(item);
        }
        
    }
    
    return registration;
    

}]);
*/

