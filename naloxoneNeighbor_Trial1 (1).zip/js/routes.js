angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    
  

      .state('naloxoneNeighbors', {
    url: '/page3',
    templateUrl: 'templates/naloxoneNeighbors.html',
    controller: 'naloxoneNeighborsCtrl'
  })

  .state('emergency', {
    url: '/page5',
    templateUrl: 'templates/emergency.html',
    controller: 'emergencyCtrl'
  })

  .state('triggered', {
    url: '/page7',
    templateUrl: 'templates/triggered.html',
    controller: 'triggeredCtrl'
  })

  .state('register', {
    url: '/page2',
    templateUrl: 'templates/register.html',
    controller: 'registerCtrl'
  })

$urlRouterProvider.otherwise('/page3')

  

});